=== Social Comments === 
Contributors: bainternet 
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=K4MMGF5X3TM5L 
Tags:  +1 comments, gplus comments, comments, google comments, google plus comments, facebook comments, disqus, disqus comments, tabbed comments. social comments.
Requires at least: 3.5 
Tested up to: 4.7.0
Stable tag: 0.1.6
License: GPLv2 or later 
License URI: http://www.gnu.org/licenses/gpl-2.0.html 
 
This plugin adds Google Plus Comments system, Facebook comments and / or Disqus Comments to your site.
 
== Description == 
	This plugin adds Google Plus Comments system, Facebook comments and / or Disqus Comments to your site.

Main Features:

* Adds Google + comments to your site.
* Adds Facebook comments to your site.
* Adds Disqus comments to your site.
* Display Comments type either stacked to tabbed.
* Drag n Drop display order.
* 14 icon sets provided.
* Add your own icon for each of the comments system.
* set the label for each of the comments system.
* set Facebook color scheme.
* set facebook language.
 
== Installation == 
1. Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation.
2. Then activate the Plugin from Plugins page.
3. Make sure you set your settings in the plugin's option panel (comments >> social comments).
4. Done! 
 
== Frequently Asked Questions == 
 You tell me!!!
 
== Screenshots == 
1. plugin option panel - Drag n drop order.
2. plugin option panel icon set picker.
3. Front-End Tabbed display.

== Changelog == 
= 0.1.6
	Fixed child theme comments not showing Native Comments.

= 0.1.5
	New option to set the facebook language.
	Facebook meta tag added when APP ID is supplied for notifications.
	wp_remote_get response is now checked to avoid errors.
	many many little bugs

= 0.1.4
	Updated readme.
	Fixed Strict Standards error.
	Added icon alt with filter `social_comments_icon_alt`.
	Added comment count for each system.

= 0.1.3
	Better child theme support.
	added text domain to translation calls and pot file

= 0.1.2
	Added settings update message.
	Fixed WordPress Comments disable not being saved.
	Added above tabs label option.
	Fixed Google plus min-height issue.
	Added link to Facebook comments moderation panel.

= 0.1.1 =
	Fixed G+ responsive width.
	Added on mouse hover tab change option.
	Added RTL support.

= 0.1.0 = 
	Initial release. 