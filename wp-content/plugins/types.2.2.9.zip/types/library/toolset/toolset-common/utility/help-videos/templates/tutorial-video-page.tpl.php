<div class="toolset-wrap">
    <div class="toolset-videos-wrapper js-toolset-videos-wrapper">
        <div id="<?php echo $element; ?>" class="<?php echo $element; ?>">
        </div>
    </div>
</div>