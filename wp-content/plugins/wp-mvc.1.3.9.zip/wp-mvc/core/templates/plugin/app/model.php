<?php echo "<?php\n"; ?>

class <?php echo $name ?> extends MvcModel {

    var $display_field = 'name';
    
}

<?php echo '?>'; ?>