<?php
//actions

//filters
define('MGMLP_FILTER_POST_TYPE_ARGS', 'mg-media-library-plus_post_type_args');


?>
