<?php
/**
 * Blank content partial template.
 *
 * @package understrap
 */

the_content();
